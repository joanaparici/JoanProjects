package com.fpmislata.JoanAparici1evalExam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JoanAparici1evalExamApplicationTests {

	@Test
	void contextLoads() {
	}

}
