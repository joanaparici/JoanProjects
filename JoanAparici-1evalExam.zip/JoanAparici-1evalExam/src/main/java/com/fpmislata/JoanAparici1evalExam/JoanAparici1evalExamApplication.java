package com.fpmislata.JoanAparici1evalExam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JoanAparici1evalExamApplication {

	public static void main(String[] args) {
		SpringApplication.run(JoanAparici1evalExamApplication.class, args);
	}

}
